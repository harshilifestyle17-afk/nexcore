const fs = require('fs');
const Papa = require('papaparse');

const csvFile = fs.readFileSync('src/ram.csv', 'utf8');
const existingJson = fs.readFileSync('src/products.json', 'utf8');
let products = JSON.parse(existingJson);

let maxId = products.reduce((max, p) => p.id > max ? p.id : max, 0);

Papa.parse(csvFile, {
  header: true,
  skipEmptyLines: true,
  complete: function(results) {
    const newProducts = [];
    results.data.forEach(row => {
      // Determine brand from name
      let brand = 'Other';
      const nameLower = (row['name'] || '').toLowerCase();
      if (nameLower.includes('corsair')) brand = 'Corsair';
      else if (nameLower.includes('adata')) brand = 'Adata';
      else if (nameLower.includes('g.skill')) brand = 'G.Skill';
      else if (nameLower.includes('kingston')) brand = 'Kingston';
      else if (nameLower.includes('crucial')) brand = 'Crucial';
      else if (nameLower.includes('teamgroup') || nameLower.includes('t-force')) brand = 'TeamGroup';

      // Parse prices
      const parsePrice = (priceStr) => {
        if (!priceStr) return 0;
        return parseInt(priceStr.replace(/[^0-9]/g, '')) / 100; // Assuming it ends with .00
      };
      const price = parsePrice(row['price-new']);
      const mrp = parsePrice(row['price-old']) || price;
      
      // Determine category (it is RAM)
      let category = 'RAM';

      if (row['name'] && price > 0) {
        maxId++;
        newProducts.push({
          id: maxId,
          title: row['name'],
          category: category,
          brand: brand,
          price: price,
          mrp: mrp,
          image: row['img-responsive src'],
          image2: row['img-responsive src 2'] || row['img-responsive src'],
          description: row['description'],
          sku: row['stat-1'],
          discount: row['product-label 5'] || '',
          url: row['product-img href'],
          inStock: true,
          popularity: Math.floor(Math.random() * (99 - 60 + 1) + 60),
          source: 'ram'
        });
      }
    });

    products = products.concat(newProducts);
    fs.writeFileSync('src/products.json', JSON.stringify(products, null, 2));
    console.log(`Added ${newProducts.length} RAM products. Total products now: ${products.length}`);
  }
});
