import os
import json
import time
from dotenv import load_dotenv
import cloudinary
import cloudinary.uploader

# Load environment variables from .env file
load_dotenv()

# Configure Cloudinary
cloudinary.config(
    cloud_name=os.getenv("CLOUDINARY_CLOUD_NAME"),
    api_key=os.getenv("CLOUDINARY_API_KEY"),
    api_secret=os.getenv("CLOUDINARY_API_SECRET"),
    secure=True
)

def upload_image_to_cloudinary(image_url):
    """Uploads an image URL to Cloudinary and returns the secure URL."""
    if not image_url or not image_url.startswith("http"):
        return image_url
    
    try:
        response = cloudinary.uploader.upload(
            image_url,
            folder="dynamic",
            overwrite=True
        )
        return response.get("secure_url")
    except Exception as e:
        print(f"Failed to upload {image_url}: {e}")
        return image_url

def main():
    json_path = os.path.join("src", "products.json")
    
    # Load the products JSON array
    try:
        with open(json_path, "r", encoding="utf-8") as file:
            products = json.load(file)
    except Exception as e:
        print(f"Error loading {json_path}: {e}")
        return

    print(f"Found {len(products)} products to process. Starting uploads...")
    
    count = 0
    total = len(products)
    
    # Iterate dynamically through all objects
    for i, product in enumerate(products):
        print(f"Processing product {i+1}/{total}: {product.get('title', 'Unknown')}")
        
        # Check and upload primary image
        if "image" in product and product["image"]:
            new_url = upload_image_to_cloudinary(product["image"])
            if new_url != product["image"]:
                product["image"] = new_url
                count += 1
                time.sleep(1) # 1-second delay to respect rate limits
        
        # Check and upload secondary image if it exists
        if "image2" in product and product["image2"]:
            new_url = upload_image_to_cloudinary(product["image2"])
            if new_url != product["image2"]:
                product["image2"] = new_url
                count += 1
                time.sleep(1) # 1-second delay
                
    # Overwrite the JSON file with updated URLs
    try:
        with open(json_path, "w", encoding="utf-8") as file:
            json.dump(products, file, indent=2, ensure_ascii=False)
        print(f"Successfully uploaded {count} images and updated {json_path}.")
    except Exception as e:
        print(f"Error writing to {json_path}: {e}")

if __name__ == "__main__":
    main()
