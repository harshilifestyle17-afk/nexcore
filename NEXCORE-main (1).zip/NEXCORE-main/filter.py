import json

with open('src/products.json', 'r', encoding='utf-8') as f:
    products = json.load(f)

# Filter out external products and graphic cards
to_remove = ["Monitors", "Peripherals", "Graphics Cards"]
filtered_products = [p for p in products if p.get('category') not in to_remove]

with open('src/products.json', 'w', encoding='utf-8') as f:
    json.dump(filtered_products, f, indent=2)

print(f"Original products: {len(products)}")
print(f"Filtered products: {len(filtered_products)}")
