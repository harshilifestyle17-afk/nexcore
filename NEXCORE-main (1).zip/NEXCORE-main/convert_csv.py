"""
NEXCORE CSV-to-JSON Converter
Reads all CSV files from src/, categorizes products based on name keywords,
cleans prices, and outputs a unified src/products.json.
"""

import csv
import json
import re
import os
import glob


# ─── Category mapping: keywords → frontend category values ───
# These MUST match the data-category values in index.html and sidebar checkbox values
CATEGORY_RULES = [
    # Order matters: more specific rules first
    # Processors
    {
        "category": "Processors",
        "keywords": [
            "processor", "ryzen", "core i3", "core i5", "core i7", "core i9",
            "cpu", "threadripper", "athlon", "pentium", "celeron",
            "ryzen 3", "ryzen 5", "ryzen 7", "ryzen 9",
        ],
    },
    # Graphics Cards
    {
        "category": "Graphics Cards",
        "keywords": [
            "graphics card", "graphic card", "geforce", "radeon",
            "rtx", "gtx", "rx 5", "rx 6", "rx 7", "rx 9",
            "rx9060", "rx7600", "rx7800", "rx7900",
            "gpu", "gddr6", "gddr6x",
        ],
    },
    # Motherboards
    {
        "category": "Motherboards",
        "keywords": [
            "motherboard", "mainboard",
            "b450", "b550", "b650", "b660", "b760", "b850",
            "x570", "x670", "x870",
            "a520", "a620", "a320",
            "h610", "h670", "h770", "h510", "h470",
            "z590", "z690", "z790", "z890",
            "lga 1700", "lga 1851", "am4", "am5",
        ],
    },
    # Monitors
    {
        "category": "Monitors",
        "keywords": [
            "monitor", "display", "27inch", "24inch", "25inch", "32inch",
            "34inch", "49inch", "mag 2", "mag 3", "optix", "g2412", "ips panel",
        ],
    },
    # RAM
    {
        "category": "RAM",
        "keywords": [
            "ram", "memory module", "ddr4 module", "ddr5 module",
            "dimm", "sodimm",
        ],
    },
    # Storage
    {
        "category": "Storage",
        "keywords": [
            "ssd", "hdd", "hard drive", "solid state", "nvme",
            "m.2 drive", "internal drive", "external drive",
        ],
    },
    # Components (Cases / PSU / Cooling)
    {
        "category": "Components",
        "keywords": [
            "power supply", "psu", "smps",
            "cabinet", "case", "chassis", "tower",
            "cooler", "cooling", "fan", "aio", "liquid cool", "coreliquid",
            "thermal paste", "thermal pad",
        ],
    },
    # Peripherals (everything else input/output related)
    {
        "category": "Peripherals",
        "keywords": [
            "mouse", "keyboard", "headset", "headphone", "earphone",
            "webcam", "camera", "microphone", "mic",
            "speaker", "soundbar",
            "gamepad", "controller", "joystick",
            "racing wheel", "steering wheel", "shifter",
            "mousepad", "mouse pad", "desk mat",
            "hub", "dock", "dongle", "adapter",
            "streamer", "stream deck", "capture card",
            "stylus", "pen tablet", "drawing tablet",
            "wireless", "bluetooth",
        ],
    },
]


def classify_product(name: str, description: str = "") -> str:
    """Determine category from product name, fallback to description."""
    name_lower = name.lower()
    
    # Check title first (highest priority)
    for rule in CATEGORY_RULES:
        for kw in rule["keywords"]:
            if kw in name_lower:
                return rule["category"]

    # If title didn't match, check description
    desc_lower = description.lower()
    for rule in CATEGORY_RULES:
        for kw in rule["keywords"]:
            if kw in desc_lower:
                return rule["category"]

    # Fallback: try to guess from URL path segments or brand context
    return "Components"  # Safe default — shows under "Cases / PSU / Cooling"


def clean_price(raw: str) -> int | None:
    """Strip ₹, commas, whitespace, decimals → pure integer. Returns None if unparseable."""
    if not raw or not isinstance(raw, str):
        return None
    # Remove ₹, Rs, Rs., commas, whitespace, and any non-numeric chars except . and -
    cleaned = raw.replace("₹", "").replace("Rs.", "").replace("Rs", "")
    cleaned = cleaned.replace(",", "").replace("\u00a0", "").strip()
    # Remove any stray Unicode chars (Â, etc)
    cleaned = re.sub(r"[^\d.]", "", cleaned)
    if not cleaned:
        return None
    try:
        return int(float(cleaned))
    except ValueError:
        return None


def extract_brand(name: str) -> str:
    """Extract brand from product name (first word or known brand pattern)."""
    known_brands = [
        "AMD", "Intel", "NVIDIA", "ASUS", "MSI", "Gigabyte", "ASRock",
        "Corsair", "G.Skill", "Kingston", "Samsung", "WD", "Seagate",
        "Crucial", "LG", "Dell", "BenQ", "Acer", "Logitech", "Razer",
        "SteelSeries", "HyperX", "NZXT", "Cooler Master", "Seasonic",
        "Lian Li", "Noctua", "Deepcool", "Thermaltake", "ARCTIC",
        "ZOTAC", "EVGA", "Sapphire", "XFX", "PowerColor", "ADATA",
    ]
    name_lower = name.lower()
    for brand in known_brands:
        if brand.lower() in name_lower:
            return brand
    # Fallback: first word
    return name.split()[0] if name else "Unknown"


def read_csv_file(filepath: str) -> list[dict]:
    """Read a single CSV, handling multiline fields and different schemas."""
    products = []
    try:
        with open(filepath, "r", encoding="utf-8-sig", errors="replace") as f:
            reader = csv.DictReader(f)
            for row in reader:
                # Clean up field names (strip whitespace)
                cleaned_row = {k.strip(): v.strip() if isinstance(v, str) else v for k, v in row.items() if k}
                products.append(cleaned_row)
    except Exception as e:
        print(f"  ⚠ Error reading {filepath}: {e}")
    return products


def normalize_product(raw: dict, product_id: int, source_file: str) -> dict | None:
    """Normalize a raw CSV row into a unified product object."""
    name = raw.get("name", "").strip()
    if not name:
        return None

    # Extract all available fields
    description = raw.get("description", "").strip()
    # Clean up description: collapse whitespace, remove trailing ".."
    description = re.sub(r"\s+", " ", description).strip()
    if description.endswith(".."):
        description = description[:-2].strip()

    stat1 = raw.get("stat-1", "").strip()

    # Images: primary and secondary
    image = raw.get("img-responsive src", "").strip()
    image2 = raw.get("img-responsive src 2", "").strip()

    # Product URL
    product_url = raw.get("product-img href", "").strip()

    # Discount label
    discount_label = (
        raw.get("product-label 4", "")
        or raw.get("product-label 5", "")
        or ""
    ).strip()

    # Prices
    price_new_raw = raw.get("price-new", "").strip()
    price_old_raw = raw.get("price-old", "").strip()

    price = clean_price(price_new_raw)
    mrp = clean_price(price_old_raw)

    # Skip products with no valid price
    if price is None or price <= 0:
        return None

    # If MRP is missing or less than price, set it to price (no discount shown)
    if mrp is None or mrp < price:
        mrp = price

    # Category & Brand
    category = classify_product(name, description)
    brand = extract_brand(name)

    # Popularity score: derived from discount percentage (bigger discount = more popular listing)
    popularity = 50  # default
    if mrp > 0 and price > 0 and mrp > price:
        discount_pct = ((mrp - price) / mrp) * 100
        popularity = min(99, int(50 + discount_pct))

    return {
        "id": product_id,
        "title": name,
        "category": category,
        "brand": brand,
        "price": price,
        "mrp": mrp,
        "image": image,
        "image2": image2 if image2 else None,
        "description": description if description else None,
        "sku": stat1 if stat1 else None,
        "discount": discount_label if discount_label else None,
        "url": product_url if product_url else None,
        "inStock": True,
        "popularity": popularity,
        "source": source_file,
    }


def main():
    src_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "src")
    csv_pattern = os.path.join(src_dir, "*.csv")
    csv_files = sorted(glob.glob(csv_pattern))

    if not csv_files:
        print("No CSV files found in src/ directory!")
        return

    print(f"Found {len(csv_files)} CSV file(s):")
    for f in csv_files:
        print(f"   - {os.path.basename(f)}")

    all_products = []
    product_id = 1

    for csv_file in csv_files:
        source_name = os.path.splitext(os.path.basename(csv_file))[0]
        print(f"\nProcessing {os.path.basename(csv_file)}...")

        raw_rows = read_csv_file(csv_file)
        print(f"   Raw rows read: {len(raw_rows)}")

        count = 0
        for row in raw_rows:
            product = normalize_product(row, product_id, source_name)
            if product:
                all_products.append(product)
                product_id += 1
                count += 1

        print(f"   Valid products extracted: {count}")

    # Print category breakdown
    print(f"\n{'='*60}")
    print(f"Total products: {len(all_products)}")
    print(f"{'='*60}")

    category_counts = {}
    for p in all_products:
        cat = p["category"]
        category_counts[cat] = category_counts.get(cat, 0) + 1

    print("\nCategory Breakdown:")
    for cat, count in sorted(category_counts.items(), key=lambda x: -x[1]):
        print(f"   {cat:20s} -> {count} products")

    # Brand breakdown
    brand_counts = {}
    for p in all_products:
        b = p["brand"]
        brand_counts[b] = brand_counts.get(b, 0) + 1

    print("\nBrand Breakdown:")
    for brand, count in sorted(brand_counts.items(), key=lambda x: -x[1]):
        print(f"   {brand:20s} -> {count} products")

    # Write output
    output_path = os.path.join(src_dir, "products.json")
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(all_products, f, indent=2, ensure_ascii=False)

    file_size = os.path.getsize(output_path)
    print(f"\nOutput written to: {output_path}")
    print(f"   File size: {file_size:,} bytes")
    print(f"   Products: {len(all_products)}")
    print(f"\nDone!")


if __name__ == "__main__":
    main()
