const fs = require('fs');

const data = fs.readFileSync('src/products.json', 'utf8');
const products = JSON.parse(data);

const toRemove = ["Monitors", "Peripherals", "Graphics Cards"];
const filteredProducts = products.filter(p => !toRemove.includes(p.category));

fs.writeFileSync('src/products.json', JSON.stringify(filteredProducts, null, 2));

console.log(`Original products: ${products.length}`);
console.log(`Filtered products: ${filteredProducts.length}`);
