const fs = require('fs');
const Papa = require('papaparse');

const csvFile = fs.readFileSync('src/PSU.csv', 'utf8');
const existingJson = fs.readFileSync('src/products.json', 'utf8');
let products = JSON.parse(existingJson);

// 1. Remove all 'Storage' products
const initialLength = products.length;
products = products.filter(p => p.category !== 'Storage');
console.log(`Removed ${initialLength - products.length} Storage products.`);

let maxId = products.reduce((max, p) => p.id > max ? p.id : max, 0);

// 2. Parse and append PSU products
Papa.parse(csvFile, {
  header: true,
  skipEmptyLines: true,
  complete: function(results) {
    const newProducts = [];
    results.data.forEach(row => {
      // Determine brand from name
      let brand = 'Other';
      const nameLower = (row['name'] || '').toLowerCase();
      if (nameLower.includes('corsair')) brand = 'Corsair';
      else if (nameLower.includes('ant esports')) brand = 'Ant Esports';
      else if (nameLower.includes('cooler master')) brand = 'Cooler Master';
      else if (nameLower.includes('thermaltake')) brand = 'Thermaltake';
      else if (nameLower.includes('deepcool')) brand = 'DeepCool';
      else if (nameLower.includes('asus') || nameLower.includes('rog') || nameLower.includes('tuf')) brand = 'ASUS';
      else if (nameLower.includes('gigabyte') || nameLower.includes('aorus')) brand = 'Gigabyte';
      else if (nameLower.includes('msi')) brand = 'MSI';
      else if (nameLower.includes('nzxt')) brand = 'NZXT';
      else if (nameLower.includes('silverstone')) brand = 'SilverStone';

      // Parse prices
      const parsePrice = (priceStr) => {
        if (!priceStr) return 0;
        return parseInt(priceStr.replace(/[^0-9]/g, '')) / 100;
      };
      const price = parsePrice(row['price-new']);
      const mrp = parsePrice(row['price-old']) || price;
      
      let category = 'PSU';

      if (row['name'] && price > 0) {
        maxId++;
        newProducts.push({
          id: maxId,
          title: row['name'],
          category: category,
          brand: brand,
          price: price,
          mrp: mrp,
          image: row['img-responsive src'],
          image2: row['img-responsive src 2'] || row['img-responsive src'],
          description: row['description'],
          sku: row['stat-1'],
          discount: row['product-label 4'] || row['product-label 5'] || '',
          url: row['product-img href'],
          inStock: true,
          popularity: Math.floor(Math.random() * (99 - 60 + 1) + 60),
          source: 'psu'
        });
      }
    });

    products = products.concat(newProducts);
    fs.writeFileSync('src/products.json', JSON.stringify(products, null, 2));
    console.log(`Added ${newProducts.length} PSU products. Total products now: ${products.length}`);
  }
});
